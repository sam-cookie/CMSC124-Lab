/*
 * IMPORTANT: Do not modify this file
 */

package lab4;

public class WordGenerator{
    private static String[] words ={"array", "public",
                    "ascii", "block", 
                    "break", "class", 
                    "field", "final", 
                    "float", "method",
                    "scope", "short", 
                    "switch", "public",
                    "object", "string",
                    "static", "print",
                    "double", "string",
                    "return", "import",
                    "while", "false"};

    private static int getRandomIndex(){
        return (int)(Math.random() * words.length);
    }

    public static String generateWord(){
        int randomIndex = getRandomIndex();
        return words[randomIndex];
    }
}